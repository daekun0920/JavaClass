package com.test.spring;

public class DTO {

}
