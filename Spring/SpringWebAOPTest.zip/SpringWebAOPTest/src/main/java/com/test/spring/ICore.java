package com.test.spring;

public interface ICore {

	int getCount();

}
