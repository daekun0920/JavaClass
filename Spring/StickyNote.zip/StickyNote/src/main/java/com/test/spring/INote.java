package com.test.spring;

public interface INote {

	int add(NoteDTO dto);

}
