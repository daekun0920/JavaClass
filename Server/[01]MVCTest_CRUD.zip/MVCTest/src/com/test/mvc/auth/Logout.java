package com.test.mvc.auth;

public class Logout {

}
