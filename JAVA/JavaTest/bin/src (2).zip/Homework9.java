
public class Homework9 {
	public static void main(String args[]) {
	/*
	 배열문제
	 
	 문제1.
	 
	 요구사항) 아래와 같이 출력하시오.
	 1    2    3    4    5
	 10	  9    8    7    6
	 11   12   13   14   15
	 20   19   18   17   16
	 21   22   23   24   25
	 
	 ====
	 0,0
	 0,1
	 0,2
	 0,3
	 0,4
	 
	 i + 1
	 
	 1,0
	 1,1
	 1,2
	 1,3
	 1,4
	 
	 i + 1
	 
	 2,0
	 2,1
	 ...
	 ====
	 */
		
		
	/*int[][] nums = new int[5][5];
	
	int n = 1;
	
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			nums[i][j] = n;
			n++;
			
		}
	}
	
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			System.out.printf("%4d", nums[i][j]);
		}
			System.out.println();
	}*/
	
		
	 /*
	 문제2.
	 
	 요구사항) 아래와 같이 출력하시오.
	  
	  25   24   23   22   21 
	  20   19   18   17   16
	  15   14   13   12   11
	  10   9    8    7    6
	  5    4    3    2    1
	 
	 ====
	 4,4
	 4,3
	 4,2
	 4,1
	 4,0
	 
	 i - 1
	 
	 3,4
	 3,3
	 3,2
	 3,1
	 3,0
	 
	 i - 1
	 
	 2,4
	 2,3
	 2,2
	 2,1
	 2,0
	 
	 i - 1
	 
	 ...
	 ====
	 */
	
	/*  int[][] nums = new int[5][5];
	
	int n = 1;
	
	for (int i = 4; i >= 0; i--) {
		for (int j = 4; j >= 0; j--) {
			nums[i][j] = n;
			n++;
			
		}
	}
	
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			System.out.printf("%4d", nums[i][j]);
		}
			System.out.println();
	}*/
	  
	  
	 /*
	 문제3.
	  
	 요구사항) 아래와 같이 출력하시오.
	  
	 1    6    11    16    21
	 2    7    12    17    22
	 3    8    13    18    23
	 4    9    14    19    24
	 5    10   15    20    25
	 
	 ====
	 0,0
	 1,0 
	 2,0
	 3,0
	 4,0
	 
	 j + 1
	 
	 0,1
	 1,1
	 2,1
	 3,1
	 4,1
	 
	 j + 1
	 
	 0,2
	 1,2
	 2,2
	 3,2
	 4,2
	 ... 
	 ==== 
	 */
	/*int[][] nums = new int[5][5];
	
	int n = 1;
	
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			nums[j][i] = n;
			n++;
			
		}
	}
	
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			System.out.printf("%4d", nums[i][j]);
		}
		System.out.println();
	}*/
	
	/*
	
	 
	 문제4.
	 
	 요구사항) 아래와 같이 출력하시오.
	  
	 1	  2    3    4    5
	 6    7    8    9    0
	 10   11   12   0    0
	 13   14   0    0    0
	 15   0    0    0    0
	 
	 ====
	 0,0
	 0,1
	 0,2
	 0,3
	 0,4
	 
	 1,0
	 1,1
	 1,2
	 1,3
	 
	 2,0
	 2,1
	 2,2
	 
	 3,0
	 3,1
	 
	 4,0
	 ====
	  */
		
	 /* int[][] nums = new int[5][5];
	  
	  int n = 1;
	  int count = 5;
	  
	  for (int i = 0; i < 5; i++) {
		  for (int j = 0; j < count; j++) {
			  nums[i][j] = n;
			  n++;
		  }
		  count = count - 1;
	  }
	  
	  for (int i = 0; i < 5; i++) {
		  for (int j = 0; j < 5; j++) {
			  System.out.printf("%4d", nums[i][j]);
			  
		  }
		  	System.out.println();
	  }*/
	  
	  
	  /*
	   * 
	 문제5.
	 
	 요구사항) 아래와 같이 출력하시오.
	 
	 0    0    1    0    0
	 0    2    3    4    0
	 5    6    7    8    9
	 0    10   11   12   0
	 0    0    13   0    0
	 
	 ====
	 0,2
	 
	 1,1
	 1,2
	 1,3
	 
	 2,0
	 2,1
	 2,2
	 2,3
	 2,4
	 
	 3,1
	 3,2
	 3,3
	 
	 4,2 
	 ====
	 */
	
		/*int[][] nums = new int[5][5];
		
		int n = 1;
		int count = 2;
		int count2 = 3;
		
		for (int i = 0; i < 3; i++) {
			for (int j = count; j < count2; j++) {
				nums[i][j] = n;
				n++;
					
			}
			count--;
			count2++;
		}
		int count3 = 1;
		int count4 = 4;
		for (int i = 3; i < 5; i++) {
			for(int j = count3; j < count4; j++) {
				nums[i][j] = n;
				n++;
			}
			count3++;
			count4--;
		}
		
		// 출력용(수정 금지)
				for (int i = 0; i < 5; i++) {
					for (int j = 0; j < 5; j++) {
						System.out.printf("%4d", nums[i][j]);
					
					}
					System.out.println();
				}*/
	 
	 /*
	 문제 1~5
	 
	 추가) 행(열)을 입력받아 출력하기 -> 행과 열을 동일한값 + 홀수만 
	 
	 
	 
	 문제6.
	 
	 요구사항) 아래와 같이 출력하시오.
 	 
 	 1   2   4   7   11
 	 3   5   8   12  16
 	 6   9   13  17  20
 	 10  14  18  21  23
 	 15  19  22  24  25
 	 
 	 ====
 	 0,0          
 	 	
 	 0,1
 	 1,0
 	 
 	 0,2
 	 1,1
 	 2,0
 	 
 	 0,3
 	 1,2
 	 2,1
 	 3,0
 	 
 	 0,4
 	 1,3
 	 2,2
 	 3,1
 	 4,0
 	 
 	 1,4
 	 2,3
 	 3,2
 	 4,1
 	 
 	 2,4
 	 3,3
 	 4,2
 	 
 	 3,4
 	 4,3
 	 
 	 5,5
 	 ====
 	 */
	/*int[][] nums = new int [5][5];			
	int n = 1;
	

	// 배열 초기화
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			nums[i][j] = n;
			n++;
		
		}
		
	}
 	 
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			System.out.printf("%4d", nums[i][j]);
		
		}
		System.out.println();
	}*/
 	 /*
 	 
	문제7.
	 
	요구사항) 아래와 같이 출력하시오.
	 
	1   2   3   4   10
	5   6   7   8   26
	9   10  11  12  42
	13  14  15  16  58
	28  32  36  40  136
	 
	====
	0,0
	0,1
	0,2
	0,3
	0,4 = 0,0 + 0,1 + 0,2 + 0,3
	
	1,0
	1,1
	1,2
	1,3 
	1,4	= 1,0 + 1,1 + 1,2 + 1,3
	
	2,0
	2,1
	2,2
	2,3
	
	3,0
	3,1
	3,2
	3,3
	====
	*/
		
	/*int[][] nums = new int[5][5];
	int n = 1;
	
	for (int i = 0; i < 4; i++) {
		for(int j = 0; j < 4; j++) {
			nums[i][j] = n;
			n++;
			
		}
	}
	int stack = 0;
	// 4 열값 
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			stack = stack + nums[i][j];
			
			
		}
		nums[i][4] = stack;
		stack = 0;
	}
	
	// 4행 값
	stack = 0;
	for (int i = 0; i < 5; i++) {
		for(int j = 0; j < 5; j++) {
			stack = stack + nums[j][i];
			
		}
		nums[4][i] = stack;
		stack = 0;
	}
	
	// 출력용(수정 금지)
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			System.out.printf("%4d", nums[i][j]);
		
		}
		System.out.println();
	}
	*/
	
	/*
	문제8.
	 
	요구사항) 아래와 같이 출력하시오.
	 
	1   2   3   4
	12  13  14  5
	11  16  15  6
	10  9   8   7 
	 
	====
	0,0
	0,1
	0,2
	0,3
	
	1,3
	2,3
	3,3
	
	3,2
	3,1
	3,0
	
	2,0
	1,0
	
	1,1
	1,2
	
	2,2
	2,1
	====
	*/
		
	int[][] nums = new int[5][5];
	
	int n = 1;
	
	for (int i = 0; i < 4; i++) {
		for(int j = 0; j < 4; j++) {
			nums[i][j] = n;
			n++;
		}
	}
	 
	 
	 
	/* 
	문제9.
	 
	요구사항) 3 x 3 마방진을 만드시오.
	 
	2   7   6
	9   5   1
	4   3   8
	 
	====
	1,2
	 
	0,0
	 
	2,1
	
	2,0
	
	1,1
	
	0,2
	
	0,1
	
	2,2
	
	1,0
	====
	 
	 문제10.
	 
	 요구사항) 임의의숫자 5개를 만드시오.
	 
	 출력) [5, 6, 1, 3, 2]
	 
	 조건) a. 숫자 범위 : 1 ~9 사이
	 	   b. 중복값 배제 
	
	 사용) 1차원 배열 사용(5칸)
	 추가) 로또 번호 생성기
	 
	 ====
	 
	 
	 
	 
	 ====
	 
	 문제11.
	 
	 요구사항) 성적을 입력받아 출력하시오.
	 
	 입력) 국어 : 80
	 	   수학 : 50
	 	   영어 : 70
	 사용) 10 x 3 배열 
	 	   String[][] score = new String[10][3];
	 	   
	 	   *    
	 	   *       *
	 	   *       *
	 	   *   *   * 
	 	   *   *   *
	 	   *   *   *
	 	   *   *   *
	 	   *   *   *
	    ===============   
	 	  국  영  수
	 ====
	 
	 
	 
	 ====
	
	 
	 문제12.
	 
	
	요구사항) 숫자 N개를 입력받아 순차적으로 출력하시오.
	입력) 총 몇개의 숫자를 입력받겠습니까? 5
		  숫자 : 5
		  숫자 : 3
		  숫자 : 14 
		  숫자 : 8
		  숫자 : 1
	출력) 14 > 8 > 5 > 3 > 1 
	사용) 1차원 배열 (n칸)
	조건) 중복 입력 받지 않기 
	추후) 정렬 알고리즘
	 
	 
	 
	 문제13.
	 
	 요구사항) 배열에서 연속된 공간 중 가장 큰 공간을 찾으시오.
	 
	 상황) String[] line = new String[20];
	 		위의 배열에 무작위로 ☆과 ★을 채워넣은 뒤 검사한다.
	 출력) ☆☆★★★☆☆☆★☆★★★★☆
	 		가장 긴 공간은 6번째 위치한 길이 3칸입니다.
	 		
	 		
	 문제14.
	 
	 요구사항) 난수를 발생시켜 배열에 넣은 뒤 같은 수가 몇개 발생했는지
	 출력하시오.
	 
	 상황) int[] nums = new int[10];
	 조건) 1 ~ 9 사이의 값
	 출력)
	 5 : 3회
	 1 : 1회
	 4 : 2회
	 8 : 1회
	 9 : 1회
	 2 : 2회
	 
	 
	 
	 문제15.
	 
	 요구사항) 사용자에게 문장을 입력받아 모음의 입력 횟수를 출력하시오.
	 상황) String[] vowel = new String[5];
	 	   int[] vowelCount = new int[5];
	 입력) 문장 : i am impressed
	 출력)
	 	a - 1회
	 	e - 2회
	 	i - 2회
	 	o - 0회
	 	u - 0회
	 */
	}
	
}
