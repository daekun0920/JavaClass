﻿
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

 /*
				이채은
					*/


public class Reserveload {
	static Scanner scan;
	static ArrayList<Reservation> reserveList;

	static {

		reserveList = new ArrayList<Reservation>(); // 모든 위시리스트를 저장한곳
		scan = new Scanner(System.in);
	}

	public static void main(String[] args) {

		//reserveload();

	}

	private static void reserveload(Member m) {
		System.out.println("=================================================");
		System.out.println("                             내 예약목록");
		System.out.println("=================================================");

		for (Reservation r : reserveList) {
			if (r.getUserId().equals(m.getMemberId())) {
				System.out.println(String.format("%s\t%s\t%s\n"
											  , r.getStoreName()
											  , r.getStoreAddress()
											  , r.getStoreTel()));
					
			}
			
		
		}
		System.out.println("============================================");
		System.out.print("삭제하실 상호명을 입력하세요 : ");
		String rdelete=scan.nextLine();
		for (Iterator<Reservation> iterator = reserveList.iterator(); iterator.hasNext();) {
			
			if(iterator.next().getStoreName().equals(rdelete)) {
				iterator.remove();
				System.out.println("삭제가 완료되었습니다.");
				break;
			}
		}
		Business.memberMenu();
		
	} // reserveLoad()

}
