﻿
import java.util.ArrayList;
import java.util.Scanner;


public class Wishload {
 			/*
				이채은
					*/

	static Scanner scan;
	static ArrayList<StoreTable> storeList;
	static final String wishPath;
	public static ArrayList<Wish> wishList;

	static {

		wishList = new ArrayList<Wish>(); // 모든 위시리스트를 저장한곳
		scan = new Scanner(System.in);
		storeList = new ArrayList<StoreTable>();
		wishPath = "./src/위시리스트.txt";
	
	
	}

	public static void main(String[] args) {

		//wloadDelete();

	}

	private static void wloadDelete(Member m) {
		System.out.println("============================================");
		System.out.println("               나의 위시리스트 보기");
		System.out.println("============================================");
		for (Wish w : wishList) {
			if (w.getMyId().equals(m.getMemberId())) {
				System.out.println(String.format("%s\t%s\t%s\t%s\t%s\n", w.getMyId()
																	   , w.getMyStoreName()
																	   , w.getMyStoreAddress()
																	   , w.getMyStoreCategory()
																	   , w.getMyStoreTel()));

			}
		}
		System.out.println("삭제하실 상호명을 입력하시오 :");
		String delete = scan.nextLine();
		for (Wish w : wishList) {
			if (w.getMyStoreName().equals(delete)) {
				wishList.remove(w);
				System.out.println("삭제가 완료되었습니다.");
				for (StoreTable t : storeList) {
					if(t.getStoreName().equals(delete)) {
					t.setFavorite(t.getFavorite()-1);
						//겟으로 가져와서 셋으로 바꿔준다.
						
					}
					
				}
			}
		}
		Business.memberMenu();
		
	}
			
}
