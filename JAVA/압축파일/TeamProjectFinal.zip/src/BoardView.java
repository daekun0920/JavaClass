
public interface BoardView {
	
	
	
	
	
}
