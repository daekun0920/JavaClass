package actor;

public class Owner extends Member {

	Owner(String memberId, String memberPw, String memberType) {
		super(memberId, memberPw, memberType);
		// TODO Auto-generated constructor stub
	}
	

	
}
