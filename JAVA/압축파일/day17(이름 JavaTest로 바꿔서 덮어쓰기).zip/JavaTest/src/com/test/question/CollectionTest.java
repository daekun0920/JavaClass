package com.test.question;

public class CollectionTest {
	
	public static void main(String[] args) {
		
		// 컬렉션 클래스를 선언하시오.
		
		// 공통
		//  a. 멤버변수
		//  b. 생성자
		//  c. toString()
		
		// 1. ArrayList
		//   a. add
		//   b. get
		//   c. set
		//   d. remove
		//   e. size
		//   f. trimToSize
		
		// 2. HashMap -> Key를 관리하는 배열 하나, Value를 관리하는 배열 하나 총 두 배열이 있어야함
		//   a. put : 추가, 수정
		//   b. get
		//   c. remove
		//   d. size
		//   e. trimToSize
		
		// 3. Stack
		//   a. push
		//   b. pop
		//   c. size
		//   d. peek
		//   e. trimToSize
		
		// 4. Queue
		//   a. add
		//   b. poll
		//   c. size
		//   d. peek
		//   e. trimToSize
		
		MyArrayList list = new MyArrayList();
		list.add("100");
		list.add("200");
		list.add("300");
		list.add("400");
		list.add("500");
		list.add("500");
		list.add("500");
		list.remove(3);
		list.add(0, "100");
		list.set(3, "100");
		list.trimToSize();
		
		
		
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		System.out.println(list.get(2));
		System.out.println(list.get(3));
		System.out.println(list.get(4));
		System.out.println(list.get(5));
		System.out.println(list.get(6));
		System.out.println(list);
		
		System.out.println(list.size());
		
		
		
		
	}

}
