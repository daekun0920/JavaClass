package com.test.question;

public class MyQueue {
	// 1. 멤버 변수
	private String[] list;
	private int index;
	private int capacity;
	
	// 2. 생성자
	public MyQueue() {
		
	}
	
	public MyQueue(int capacity) {
		
	}
	
	// 3. toString
	@Override
	public String toString() {
		return super.toString();
	}
	
	// 4. 주업무
	
	// add
	public void add() {
		
		
	}
	
	// poll
	public String poll() {
		
		
		
		return null;
	}
	
	// size
	public int size() {
		
		
		
		return 0;
	}
	
	// peek
	public String peek() {
		
		
		return null;
	}
	
	// trimToSize
	public void trimToSize() {
		
		
		
	}
	
}
