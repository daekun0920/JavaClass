package com.test.question;

public class test22 {
	public static void main(String[] args) {
		String[] list = new String[4];
		System.out.println(list.length);
	}
}
