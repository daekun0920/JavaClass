package com.test.example;

public class Smartphone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
