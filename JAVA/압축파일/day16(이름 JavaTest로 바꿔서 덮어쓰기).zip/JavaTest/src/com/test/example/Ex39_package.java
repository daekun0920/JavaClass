package com.test.example;

public class Ex39_package {

	public static void main(String[] args) {
		
		// Ex39_package.java
		
		// 패키지, package
		//   - 클래스를 분류, 관리하는 역할
		//   - 물리 폴더
		
		// 코드 관리 단위
		//   - 메소드 (가장 작은 단위) < 클래스 < 패키지 < *.jar(zip)		
		//   - 배포의 단위 -> *.jar
		
		// 패키지명은 반드시 소문자로만, 특수문자는 절대 쓰지않고 숫자는 거의 사용하지않는다.
		
		
		
	}

}
