package com.test.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class Ex80_Collection {
	
	public static void main(String[] args) {
		
		// Ex80_Collection.java
		// m1();
		// m2();
		m3();
		
	}

	private static void m3() {
		
		// 정렬, Sort
		//	-> 스왑, Swap
		// 1. 버블 정렬
		// 2. 선택 정렬
		// 3. 삽입 정렬
		// ============
		// 4. 퀵 정렬 (퀵 정렬이 대체적으로 가장 무난하며 보편적으로 쓰인다)
		// 5. 힙 정렬
		// 6. 병합(머지) 정렬
		// 7. 기수 정렬 
		
		int[] nums = new int[] {10, 50, 30};
		
		// for 문 돌렸다는 전제하에 
		// 해당 방 < 다음 방
		int temp = 0;
		
		if (nums[0] < nums[1]) {
			temp = nums[0];
			nums[0] = nums[1];
			nums[1] = temp;
		}
		System.out.println(Arrays.toString(nums));
		
	}

	private static void m2() {
		
		// 순수 배열
		String[] list = new String[] {
				"홍길동", "아무개", "하하하", "호호호", "유재석", "박명수"
			  , "정형돈", "정준하", "강호동", "이수근"
		};
		
		// 규모
		// 1. 작은 코드 > 도움말
		// 2. 큰 코드 > 구글
		// 3. 대형 코드(소규모 프로젝트 단위) > 구글, 해외 커뮤니티
		//                                            - codeproject.com
		// 4. 문제 > 구글, StackOverflow.com ***
		
		
		// *.clone();
		String[] copy = list.clone(); // 깊은 복사 
		String[] copy2 = list; // 얕은 복사
		
		list[0] = "김길동";
		
		System.out.println(copy[0]);  // 깊은 복사 
		System.out.println(copy2[0]); // 얕은 복사
	
		// 컬렉션 생성하기(X)
		List<String> temp = Arrays.asList("아무개", "하하하", "호호호");
		
		System.out.println(temp.get(0));
		
		// 순수배열 -> 컬렉션(ArrayList) 변환하기(*****)
		List<String> temp2 = Arrays.asList(list);
		
		System.out.println(temp2.toString());
		
		
		// 배열 부분 복사(깊은 복사)
		String[] temp3 = Arrays.copyOf(list, 3); // 0 ~ 2  인덱스
		System.out.println(Arrays.toString(temp3));
		
		// 배열 부분 복사 (*****)
		String[] temp4 = Arrays.copyOfRange(list, 3, 6); // 3 ~ 5  인덱스
		
		
		// 배열 비교 // int[] 는 값형이라 deepEquals가 안됨 -> Integer(참조형) 으로 변환
		Integer[] ns1 = new Integer[] {100, 200, 300};
		Integer[] ns2 = new Integer[] {100, 200, 300};
		
		System.out.println(ns1 == ns2); // 참조 변수 비교 = 주소값 비교
		System.out.println(ns1.equals(ns2)); // 위와 같음(주소값 비교 -> 오버라이드 되지 않았음)
		
		// deepEquals();
		System.out.println(Arrays.deepEquals(ns1, ns2));
		
		
		// 배열 채우기
		String[] temp5 = new String[10]; // null
		// loop -> [i] = "미정";
		// Arrays.fill(temp5, "미정"); // 모든 방을 다 채우기
		Arrays.fill(temp5, 3, 7, "미정");  // 3 ~ 6 인덱스 방만 채우기 
						   // 덤프해주는 메소드 Arrays.toString 
		System.out.println(Arrays.toString(temp5));
		
		
		
		
		
	}
	private static void m1() {
		
		// List 계열
		// 1. ArrayList
		// 2. Vector
		//  - 동일한 컬렉션
		//  - 유일한 차이 : 쓰레드 작업 시 동기화 지원 유무
		
		int[] nums1 = new int[5];
		
		nums1[0] = 10;
		nums1[1] = 30;
		nums1[2] = 20;
						  // 덤프해주는 메소드 Arrays.toString 
		System.out.println(Arrays.toString(nums1));
		
		// ----------------------------------------------------- //
		
		ArrayList<Integer> nums2 = new ArrayList<Integer>();
		
		nums2.add(100);
		nums2.add(300);
		nums2.add(200);
						// ArrayList.toString (조상중에 한명이 오버라이드함)
		System.out.println(nums2.toString());
		
		// ArrayList 와 똑같음 
		Vector<Integer> nums3 = new Vector<Integer>();
		
		nums3.add(1000);
		nums3.add(3000);
		nums3.add(2000);
		
		System.out.println(nums3.toString());
		
	}
	
}
