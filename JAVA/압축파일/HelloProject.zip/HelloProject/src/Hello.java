
public class Hello {

	public static void main(String[] args) {
		
		// Ctrl + F11
		System.out.println("안녕하세요.");
		
	}
	
}

