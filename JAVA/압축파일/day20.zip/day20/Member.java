package com.test.io;

// Ex70 예제와 동일
// 김덕배,42,수원시,010-3030-3030
public class Member { // 한줄을 담기위한 객체 
	
	private String name;
	private String age;
	private String address;
	private String tel;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	
}
