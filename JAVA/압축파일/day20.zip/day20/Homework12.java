package homework;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Stack;

public class Homework12 {
	
	private static ArrayList<Grade> list;
	
	static {
		list = new ArrayList<Grade>();
	}
	
	public static void main(String[] args) {
		
	
	/*
	 파일 입출력 - 데이터 조작
	  	- 파일 입출력 문제 . zip
	 
	 문제1.
	 리소스] 숫자.dat
	 요구사항] 아라비안 숫자를 찾아서 한글로 바꾸시오. -> 복사본으로 저장하기
	 조건] 0 -> 영, 1 -> 일, ... 9 -> 구
	 	   저장할 파일명 : 숫자_변환.dat
	 */
	
		//changeNumbers();
		
		
	 
	 /*
	 문제2.
	 리소스] 성적.dat
	 파일형식] 홍길동,47,61,73
	 		   이름, 국, 영, 수 
	 
	 요구사항] 합격자 명단을 출력하시오.
	 조건] 합격 조건 : 3과목 평균 60점 이상
	 	   과락 조건 : 40점 미만
	 결과] 홍길동
	 	   하하
	 	   정형돈
	 사용] 컬렉션 사용해서..(Ex77 예제)
	 
	 */
	getGrade();
		
		
	/*
	 문제3. - 문제1과 동일
	 리소스] 이름수정.dat
	 요구사항] '유재석'을 '메뚜기'로 수정하시오.
	 조건] 이름수정_변환.dat
	 
	 
	 문제4.
	 요구사항] 임의의 숫자를 10개를 입력받아 파일에 저장하시오.
	 입력] 숫자 : 5
	 	   숫자 : 3
	 	   숫자 : 100
	 	   숫자 : 22
	 	   ..
	 
	 파일저장] 
	 100	 
	 22
	 5
	 3
	 
	 조건] 배열 or 컬렉션 사용하지 말 것 (스트림을 적을때 판단)
	 */
	
	 /*
	 문제5.
	 리소스] 일기.dat
	 요구사항] 적혀있는 문장들을 역순으로 저장하시오.
	 조건] 일기_역순.dat
	 */
	// load();
	
	
	
	
	/*
	 ----------------------------------------------------------------
	 
	 
	 문제6.
	 리소스] 단일검색.dat
	 요구사항] 이름을 검색 -> 해당 회원의 모든 정보를 출력하시오.
	 입력] 이름 : 홍길동
	 출력] 
	 번호 : 33
	 이름 : 홍길동
	 주소 : 서울시 강남구 역삼동
	 전화 : 010-2345-6778
	 
	 
	 문제7.
	 리소스] 검색_회원.dat, 검색_주문.dat 
	 						(주문번호, 물품이름, 수량, 회원번호) 
	 요구사항] 이름을 검색 -> 주문내역을 출력하시오. (한사람이 여러개의 주문이 있을수있다는 가정하에)
	 입력] 회원명 : 홍길동
	 출력] 구매내역
	 [번호]   [이름]   [상품명]   [개수]   [배송지]
	 3 		  홍길동	마우스     3  		서울시 강동구 길동
	 
	 사용] 컬렉션 사용
	 
	 
	 문제8.
	 리소스] 괄호.java
	 요구사항] 괄호들이 쌍이 맞는지 안맞는지 검사?
	 결과] 올바른(올바르지 않은) 소스입니다. (바르게 직접 수정후) -> 올바른 소스입니다.
	 대상] (), {}
	 사용] stack  (필수는 x)
	 
	 
	 
	 문제9.
	 리소스] 자바소스.java, 자바예약어.dat
	 요구사항] 소스에서 예약어가 총 몇회 사용되었는지?
	 결과]
	 if : 5회
	 continue : 2회
	 ..
	 abstract : 0회
	 
	 
	 /*
	 문제10.
	 리소스] 출결.dat  날짜,이름,출근시간,퇴근시간
	 요구사항] 각 직원별로 지각횟수, 조퇴횟수를 카운트하시오.
	 조건] 출근 : 정각 9시
	       퇴근 : 정각 6시 
	 
	 결과] 총카운트
	 추가] 날짜별 카운트
	 
	 */
		
	
	}


	private static void getGrade() {
		/*
		 문제2.
		 리소스] 성적.dat
		 파일형식] 홍길동,47,61,73
		 		   이름, 국, 영, 수 
		 
		 요구사항] 합격자 명단을 출력하시오.
		 조건] 합격 조건 : 3과목 평균 60점 이상
		 	   과락 조건 : 40점 미만
		 결과] 홍길동
		 	   하하
		 	   정형돈
		 사용] 컬렉션 사용해서..(Ex77 예제)
		 
		 */
		String path = "D:\\Class\\Java\\파일_입출력_문제\\성적.dat";
		String line = "";
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(path));
			
			while ((line = reader.readLine()) != null) {
				String[] info = line.split(",");
				
				Grade g = new Grade();
				g.setName(info[0]);
				g.setKor(info[1]);
				g.setEng(info[2]);
				g.setMath(info[3]);
				
				list.add(g);
				
			}
			reader.close();
			String passedStudents = "";
			
			for (int i = 0; i < list.size(); i++) {
				int korScore = Integer.parseInt(list.get(i).getKor());
				int engScore = Integer.parseInt(list.get(i).getEng());
				int mathScore = Integer.parseInt(list.get(i).getMath());
				
				int average = (korScore + engScore + mathScore) / 3;
				if (korScore < 40 || engScore < 40 || mathScore < 40) {
					continue;
				} else if (average < 60) {
					continue;
				} else {
					passedStudents = passedStudents + list.get(i).getName() + "\r\n";
				}
				
			}
			
			System.out.printf("[합격한 학생] \n%s", passedStudents);
		} catch (Exception e) {
			System.out.println("getGrade : " + e.toString());
		}
		
		
		
		
		
		
		
		
		
	}


	private static void changeNumbers() {
		String path = "D:\\Class\\Java\\파일_입출력_문제\\숫자.dat";
		String line = "";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String doc = "";
			String temp = "";
			
			while ((line = reader.readLine()) != null) {
				doc = line.replace("0", "영");
				doc = doc.replace("1", "일");
				doc = doc.replace("2", "이");
				doc = doc.replace("3", "삼");
				doc = doc.replace("4", "사");
				doc = doc.replace("5", "오");
				doc = doc.replace("6", "육");
				doc = doc.replace("7", "칠");
				doc = doc.replace("8", "팔");
				doc = doc.replace("9", "구");
				temp = temp + doc + "\r\n";
			}
			reader.close();
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(path));
			writer.write(temp);
			
			System.out.println("성공적으로 변환을 완료했습니다.");
			writer.close();
		} catch (Exception e) {
			System.out.println("changeNumbers : " + e.toString());
		}
		
		
		
		
	} // changeNumbers(#1) 


	private static void load() {
		String path = "D:\\일기.txt";
		try {
			
			BufferedReader reader = new BufferedReader(new FileReader(path)); // Reader와 Writer 동시에 선언하면 X 
			Stack<String> stack = new Stack<String>(); 
			
			
			
			String line = "";
			String diary = "";
			
			while ((line = reader.readLine()) != null) {
				stack.push(line);
			}
			reader.close();
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(path));
			while (stack.size() > 0) {
				diary = diary + stack.pop() + "\r\n";
			}
		
			writer.write(diary);
		
			writer.close();
			
			System.out.println("완료 되었습니다.");
		} catch (Exception e) {
			System.out.println("load : " + e.toString());
		}
		
	} // load (#5)
	
}
