package teacher.model;

public class TeacherStudentEditDTO {

}
