package adminattendance.view;

public class AdminAttendanceView {

	public void menu() {
		
		System.out.println("-=-=-=-=-=-=-=-={쌍용교육센터 관리 프로그램}=-=-=-=-=-=-=-=-");
		System.out.println("===============================================================");
		System.out.println("|                       1. 전체 출결 조회                     |");
		System.out.println("|                       2. 출결 상태 수정                     |");
		System.out.println("|                       3. 돌아가기                           |");
		System.out.println("===============================================================");
		System.out.print("                           입력 : ");
		
		
	}

}
