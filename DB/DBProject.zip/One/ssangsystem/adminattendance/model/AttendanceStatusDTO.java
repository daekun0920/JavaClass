package adminattendance.model;

public class AttendanceStatusDTO {

}
