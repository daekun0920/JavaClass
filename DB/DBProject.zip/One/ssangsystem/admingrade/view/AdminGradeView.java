package admingrade.view;

public class AdminGradeView {

	public void menu() {
	
		System.out.println("-=-=-=-=-=-=-=-=-={쌍용교육센터 관리 프로그램}=-=-=-=-=-=-=-=-");
		System.out.println("===============================================================");
		System.out.println("|               1. 성적 & 시험날짜 등록 여부 조회             |");
		System.out.println("|                     2. 과목별 성적 정보 조회                |");
		System.out.println("|                     3. 개인별 성적 정보 조회                |");
		System.out.println("|                       4. 돌아가기                           |");
		System.out.println("===============================================================");
		System.out.print("                            입력 : ");
		
	}

}
