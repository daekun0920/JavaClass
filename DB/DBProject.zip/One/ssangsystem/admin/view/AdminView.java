package admin.view;

public class AdminView {

	public void menu() {
		
		System.out.println("-=-=-=-=-=-=-=-=-={쌍용교육센터 관리 프로그램}=-=-=-=-=-=-=-=-=-");
		System.out.println("===============================================================");
		System.out.println("|                       1. 개설 과정 관리                     |");
		System.out.println("|                       2. 개설 과목 관리                     |");
		System.out.println("|                       3. 교사 계정 관리                     |");
		System.out.println("|                       4. 교육생 계정 관리                   |");
		System.out.println("|                       5. 성적 조회                          |");
		System.out.println("|                       6. 출결 관리 및 조회                  |");
		System.out.println("|                       7. 교육생 수강평 관리                 |");
		System.out.println("|                       8. 돌아가기                           |");
		System.out.println("===============================================================");
		System.out.print("                           입력 : ");
		
	}

	

}
