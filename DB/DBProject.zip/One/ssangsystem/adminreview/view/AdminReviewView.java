package adminreview.view;

public class AdminReviewView {

	public void menu() {
		
		
		
		System.out.println("-=-=-=-=-=-=-=-=-={쌍용교육센터 관리 프로그램}=-=-=-=-=-=-=-=-=-");
		System.out.println("===============================================================");
		System.out.println("|                       1. 수강평 조회 및 삭제                |");
		System.out.println("|                       2. 돌아가기                           |");
		System.out.println("===============================================================");
		System.out.print("                           입력 : ");
		
	}

}
