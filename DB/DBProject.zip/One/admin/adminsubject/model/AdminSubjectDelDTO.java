package adminsubject.model;
//5. 개설과목 삭제 subject_del()
public class AdminSubjectDelDTO {
	
	private String subjectseq;

	public String getSubjectseq() {
		return subjectseq;
	}

	public void setSubjectseq(String subjectseq) {
		this.subjectseq = subjectseq;
	}

}
