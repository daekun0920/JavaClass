package adminsubject.model;
//5. 개설과목 교재명조회 basic_book()

public class AdminbasicbookDTO {
	private String bookseq;
	private String bookname;

	public String getBookseq() {
		return bookseq;
	}

	public void setBookseq(String bookseq) {
		this.bookseq = bookseq;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

}
