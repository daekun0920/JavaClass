package adminsubject.model;
//5. 개설과목 기초과목조회 subject_name_list()

public class AdminbasicSubjectListDTO {

	private String subjectbasicseq;
	private String subjectbasicname;

	public String getSubjectbasicseq() {
		return subjectbasicseq;
	}

	public void setSubjectbasicseq(String subjectbasicseq) {
		this.subjectbasicseq = subjectbasicseq;
	}

	public String getSubjectbasicname() {
		return subjectbasicname;
	}

	public void setSubjectbasicname(String subjectbasicname) {
		this.subjectbasicname = subjectbasicname;
	}

}
