package adminsubject.model;
//5. 개설과목 기초교사조회 teacher_list()

public class AdmindetilteacherDTO {

	private String teacherseq;
	private String teachername;

	public String getTeacherseq() {
		return teacherseq;
	}

	public void setTeacherseq(String teacherseq) {
		this.teacherseq = teacherseq;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

}
