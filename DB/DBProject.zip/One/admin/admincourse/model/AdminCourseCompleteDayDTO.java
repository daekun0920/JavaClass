package admincourse.model;

public class AdminCourseCompleteDayDTO {
	

}
