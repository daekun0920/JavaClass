package admincourse.model;
//4.개설과정 삭제 course_del()

public class AdminCourseDelDTO {
	
	private String courseseq;

	public String getCourseseq() {
		return courseseq;
	}

	public void setCourseseq(String courseseq) {
		this.courseseq = courseseq;
	}
	
	

}
