package admincourse.model;
// 4. 개설과정 강의실정보 course_class_list()
public class AdminCoursebasicroomDTO {

	private String roomseq;
	private String roomname;

	public String getRoomseq() {
		return roomseq;
	}

	public void setRoomseq(String roomseq) {
		this.roomseq = roomseq;
	}

	public String getRoomname() {
		return roomname;
	}

	public void setRoomname(String roomname) {
		this.roomname = roomname;
	}

}
