package student.model;

public class StudentMyInfoListDTO {

	/*
	 *  교육생 타이틀 출력 DTO 
	 * 
	 * 
	 * 	 교육생 본인의 정보와 본인의 과정 정보
	 * 
	 */
	
	
	private String seq;
	private String name;
	private String tel;
	private String course;
	private String date;
	private String room;


	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public void setInt(int mseq) {
		// TODO Auto-generated method stub
		
	}
	public void setString(String mseq) {
		// TODO Auto-generated method stub
		
	}




}

