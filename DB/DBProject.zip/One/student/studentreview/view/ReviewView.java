package studentreview.view;

import member.auth.Auth;

public class ReviewView {

public void menu() {
		
		System.out.println("====================");
		System.out.println("[수강평관리]");
		System.out.println("====================");
		System.out.println("1. 모든 수강평 조회");
		System.out.println("2. 내 수강평 조회");
		System.out.println("3. 내 수강평 작성");
		System.out.println("4. 내 수강평 수정");
		System.out.println("5. 내 수강평 삭제");
		System.out.println("6. 상위 메뉴로..");
		System.out.print("선택 : ");
		
	}
}
