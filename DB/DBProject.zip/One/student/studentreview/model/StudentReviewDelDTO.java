package studentreview.model;

public class StudentReviewDelDTO {

	
	/*
	 * 
	 * 	 리뷰 삭제 DTO
	 * 
	 *  본인의 리뷰를 삭제함
	 * 
	 */
	
	private String student_enrollment_seq;
	
	public String getStudent_enrollment_seq() {
		return student_enrollment_seq;
	}
	public void setStudent_enrollment_seq(String student_enrollment_seq) {
		this.student_enrollment_seq = student_enrollment_seq;
	}

	


	
}


