package studentinout.view;

public class StudentInOutView {
	
public void menu() {
		
		System.out.println("====================");
		System.out.println("[출결관리 & 조회]");
		System.out.println("====================");
		System.out.println("1. 출결 조회(전체)");
		System.out.println("2. 출결 조회(월)");
		System.out.println("3. 출결 조회(일) ");
		System.out.println("4. 출근 등록");
		System.out.println("5. 퇴근 등록");
		System.out.println("6. 상위 메뉴로..");
		System.out.print("선택 : ");
		
	}
}
