package studentinout.model;

public class StudentInoutdAddDTO {
	private String studentseq;
	private String rs;
	
	
	public String getStudentseq() {
		return studentseq;
	}
	public void setStudentseq(String studentseq) {
		this.studentseq = studentseq;
	}
	public String getRs() {
		return rs;
	}
	public void setRs(String rs) {
		this.rs = rs;
	}
	
	
	
}
