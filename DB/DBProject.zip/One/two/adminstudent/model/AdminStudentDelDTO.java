package adminstudent.model;
/*
관리자 - 6. 교육생계정관리
AdminStudentClass
del()에 쓰임

*/
public class AdminStudentDelDTO {

	private String num;

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}
	
	
}
