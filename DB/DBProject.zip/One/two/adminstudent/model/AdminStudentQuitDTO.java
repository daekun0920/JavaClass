package adminstudent.model;
/*
관리자 - 6. 교육생계정관리
AdminStudentClass
edit_enrollment_quit()에 쓰임

*/
public class AdminStudentQuitDTO {

	private String seq;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}

	
}
