package adminstudent.model;
/*
관리자 - 6. 교육생계정관리
AdminStudentClass
edit()에 쓰임

*/
public class AdminStudentEditDTO {

	private String seq;
	private String tel;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	
	
}
