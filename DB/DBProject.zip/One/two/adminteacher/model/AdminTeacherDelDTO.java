package adminteacher.model;
/*
관리자 - 3. 교사계정관리
AdminTeacherClass
del()에 쓰임

*/
public class AdminTeacherDelDTO {

	private String num; //교사번호

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}
	
}
