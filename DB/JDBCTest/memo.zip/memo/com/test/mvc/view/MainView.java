package com.test.mvc.view;

import java.util.Scanner;

public class MainView {

	public void menu() {
		
		System.out.println("===================");
		System.out.println("회원 + 메모");
		System.out.println("===================");
		System.out.println("1. 회원 업무");
		System.out.println("2. 메모 업무");
		System.out.print("선택 : ");
		
	}

	public void close() {
		System.out.println("프로그램을 종료합니데이");
		
	}

}
